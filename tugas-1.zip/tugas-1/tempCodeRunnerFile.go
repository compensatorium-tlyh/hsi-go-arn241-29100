division(2, 3)
	// d, er := division(4, 0)
	// fmt.Println(c, d, er)

	// var f, g float64
	// f, _ = logarithm(100)
	// g, er = logarithm(-10)
	// fmt.Prin